console.log("satyam jha");

let button = document.getElementById("processButton");
let uploadfilebox = document.getElementsByClassName("uploadfilebox");

button.addEventListener("click", () => {
  uploadfilebox.style.display = "none";
});
.